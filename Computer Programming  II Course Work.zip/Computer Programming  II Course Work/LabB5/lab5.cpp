

#include <iostream> //Header File
#include <fstream>  //Header File
#include <string>   //Header File
#include <vector>   //Header File
#include <iomanip>  //Header File

using namespace std;

class books         //Books Class
{
private:
	 /*static*/int numberOfSuccessfulTransaction;
	 /*static*/int numberOfUnSuccessfulTransaction;
	void updateStock(string parAuthor, string parTitle, int parReduceNumber);

public:
	books();
	void searchBook(string parAuthor, string parTitle);
};  //End of Books class

books::books() {
	books::numberOfSuccessfulTransaction = 0;
	books::numberOfUnSuccessfulTransaction = 0;
}

void books::searchBook(string parAuthor, string parTitle) {
	ifstream reader("BookInformation.txt");
	string stAuthor, stTitle, stPublisher;
	int iNumberOfCopies, iNeededCopies;
	float iPrice;

	bool isFound = false;

	while ( !reader.eof() ) {   //Loop used to repeat check
		reader >> stAuthor;
		reader >> stTitle;
		reader >> iPrice;
		reader >> stPublisher;
		reader >> iNumberOfCopies;
		if ( stAuthor == parAuthor && stTitle == parTitle ) {
			isFound = true;
			break;
		}
	}
	reader.close();
	if ( isFound ) {    //Action to be taken if the book entered was found
    cout << "|=============================================|\n";// << endl;
    cout << "|       The book you entered was Found!       |\n";// << endl;
    cout << "|=============================================|\n";// << endl;
	cout << "| Author's Name:  " << stAuthor << "                      |" << endl;
    cout << "| Book Title: " << stTitle << "                             |" << endl;
    cout << "| Unit Price: $" << iPrice  << "                           |" << endl;
    cout << "| Publisher :  "  << stPublisher << "                        |" << endl;
    cout << "|=============================================|\n" << endl;


		cout << "Enter Number of Copies: " ;
		cin >> iNeededCopies;

		if ( iNumberOfCopies < iNeededCopies ) {    //Action to be taken if the required amount of books needed is more than the books available in stock
			cout << "I'm sorry, not enough copies in stock!" << endl;
            cout << "The amount of copies available in stock is " << iNumberOfCopies << endl;
			books::numberOfUnSuccessfulTransaction ++;
		}
		else {  //Displays the total cost of the books requested by the user
			cout << "The total cost is: " << iPrice * iNeededCopies << endl;
			updateStock(stAuthor, stTitle, iNeededCopies);
			books::numberOfSuccessfulTransaction ++;
			cout <<"Press (CTRL and C) to end program\n" << endl;

		}
	}
	else {  //Action to be taken if book required by user is not in stock
		cout << "Required copies not in stock. \n" << endl;
		books::numberOfUnSuccessfulTransaction ++;
	}
}

void books::updateStock(string parAuthor, string parTitle, int parReduceNumber) {
	vector<string> vecStAuthor;
	vector<string> vecStTitle;
	vector<float> vecIPrice;
	vector<string> vecStPublisher;
	vector<int> vecINumberOfCopies;

	ifstream reader("BookInformation.txt");

	string stAuthor, stTitle, stPublisher;
	int iNumberOfCopies, iNeededCopies;
    float iPrice;

	while ( !reader.eof() ) {
		reader >> stAuthor;
		reader >> stTitle;
		reader >> iPrice;
		reader >> stPublisher;
		reader >> iNumberOfCopies;
		if ( stAuthor == parAuthor && stTitle == parTitle ) {
			iNumberOfCopies -= parReduceNumber;
		}
		vecStAuthor.push_back(stAuthor);
		vecStTitle.push_back(stTitle);
		vecIPrice.push_back(iPrice);
		vecStPublisher.push_back(stPublisher);
		vecINumberOfCopies.push_back(iNumberOfCopies);
	}
	reader.close();

	ofstream writer("BookInformation.txt");

	int iIndex = 0;
	while ( iIndex < vecStAuthor.size() ) {
		writer << vecStAuthor[iIndex] << endl;
		writer << vecStTitle[iIndex] << endl;
		writer << vecIPrice[iIndex] << endl;
		writer << vecStPublisher[iIndex] << endl;
		writer << vecINumberOfCopies[iIndex] << endl;
		iIndex ++;
	}
	writer.close();
}

 void TableLayout()
 {
    cout << "|==========================================================================|" << '\n';
    cout << '|' << setw(45) << "Bookshop Inventory" << setw(30) << '|' << '\n';  // use endl to push to screen
	cout << "|==========================================================================|" << endl;
	cout << "| Author's Name|";
    cout << "| Book Title  |";
    cout << "| Unit Price  |";
    cout << "| Publisher   |";
    cout << "| Stock Count |" << endl;
    cout << "|==========================================================================|\n" << endl;
 }; //End of basic Layout for table (Header).

int main() {

	TableLayout(); //Runs Table Layout function (Header)
	cout <<"Enter (exit) or press (CTRL and C) to end program\n" << endl;
	string author;
	string title;
	books newCostomer;
	while ( true ) {

		cout << "Please enter Author's Name: \n";
		cin >> author;
		if ( author == "exit" ) break;
		cout << "Please Enter Book Title: " << endl << endl;
		cin >> title;
		if ( title == "exit" ) break;
		newCostomer.searchBook(author, title);
	}
	return 0;
}
